# landingpage
simple landing page for start up companies.
